﻿<?php echo $__env->yieldContent('content'); ?>


<style>
footer {
	background: #000;
	border-top: 8px solid #fa0;
}
footer .container {
	padding-bottom: 16px;
	border-bottom: 2px solid #808080;
}
footer .title {
	margin: 16px 0 8px 0;
	font-size: 24px;
	color: #fff;
}
footer li, footer li a:link, footer li a:visited {
	color: #c0c0c0;
}
footer li a:hover {
	color: #fa0;
}
footer li a:active {
	color: #fc0;
}
footer .qrcode {
	width: 100%;
	max-width: 120px;
}
footer>div+div {
	text-align: center;
	color: #808080;
}
#footer-copyright{
	margin-top: 16px;
}
#footer-qualification{
	padding: 4px 0 16px 0;
}
#footer-qualification a {
	display: inline-block;
	margin: 0 1em;
	text-decoration:none;
	color: #808080;
}
#footer-qualification a:hover {
	color: #fff;
}

@media (max-width:767px) {
footer li {
	float: left;
	list-style: none;
}
footer li:after {
	content: "|";
	padding: 0 1em;
	color: #eee;
}
footer li:last-child:after {
	content: "";
}
footer .qrcode {
	margin-left: 35%;
	width: 30%;
	max-width: 100%;
}
}
</style>
<div class="container">
  <div class="row">
    <div class="col-xs-12 col-sm-3" id="footer-nav">
      <div class="title">站内导航</div>
      <ul>
        <li><a href="../">老山 &middot; 首页</a></li>
        <li><a href="../outdoors">老山 &middot; 户外</a></li>
        <li><a href="../sceneries">老山 &middot; 景点</a></li>
        <li><a href="../houses">老山 &middot; 民宿</a></li>
        <li><a href="../goods">老山 &middot; 商城</a></li>
        <li><a href="../news">老山 &middot; 新闻</a></li>
      </ul>
    </div>
    <div class="col-xs-12 col-sm-3" id="footer-about">
      <div class="title">关于我们</div>
      <ul>
        <li><a href="about" onclick="return showAbout()">老山简介</a></li>
        <li><a href="about" onclick="return showAbout()">联系我们</a></li>
        <li><a href="about" onclick="return showAbout()">合作伙伴</a></li>
        <li><a href="about" onclick="return showAbout()">服务热线</a></li>
        <li><a href="about" onclick="return showAbout()">服务时间</a></li>
      </ul>
    </div>
    <div class="col-xs-12 col-sm-3" id="footer-links">
      <div class="title">友情链接</div>
      <ul>
        <li><a href="http://www.nanjing.gov.cn/" target="_blank">南京政府</a></li>
        <li><a href="http://www.nju.gov.cn/" target="_blank">南京旅游</a></li>
        <li><a href="http://www.pukou.gov.cn/" target="_blank">浦口区政府</a></li>
        <li><a href="http://pkls.pukou.gov.cn/djqgk/" target="_blank">南京旅游度假区</a></li>
        <li><a href="http://www.laoshanpark.com/" target="_blank">南京老山森林公园</a></li>
      </ul>
    </div>
    <div class="col-xs-12 col-sm-3" id="footer-qrcode">
      <div class="title">微信号</div>
      <img class="qrcode" src="http://photo.idate.163.com/siteimg/yuehui2/pc/download/v2/qr.png" /></div>
  </div>
</div>
<div id="footer-copyright">
  <div>版权所有：南京老山户外健身运动俱乐部</div>
</div>
<div id="footer-qualification"><a href="#" target="_blank">苏ICP证书B1.B2-20140145</a><a href="http://www.miibeian.gov.cn/" target="_blank">苏ICP备13015215号-1</a></div>
<div id="modal-box"></div>
</body>
</html>