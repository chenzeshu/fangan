<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('/resources/views/admin/style/js/login/css/mui.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('/resources/views/admin/style/js/login/css/style.css')); ?>" rel="stylesheet" />
    <!--面包屑导航 开始-->
    <div class="crumb_warp">
        <!--<i class="fa fa-bell"></i> 欢迎使用登陆网站后台，建站的首选工具。-->
        <i class="fa fa-home"></i> <a href="<?php echo e(url('admin/mx')); ?>">首页</a> &raquo; <a href="#">绩效明细表</a>
    </div>
    <!--面包屑导航 结束-->

    <div class="result_wrap">
        <div class="result_title">
            <div class="mark">
                <?php if(is_object($errors)): ?>
                    <?php if(count($errors)>0): ?>
                        <?php foreach($errors->all() as $error): ?>
                            <p><?php echo e($error); ?></p>
                        <?php endforeach; ?>
                    <?php endif; ?>
                <?php else: ?>
                    <p><?php echo e($errors); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!--搜索结果页面 列表 开始-->
        <div class="result_wrap">
            <div class="result_title">
                <h3>绩效明细表</h3>
            </div>
            <!--快捷导航 开始-->
            <div class="result_content">
                <div class="short_wrap">
                    <a href="<?php echo e(url('gongzi/god_jixiao')); ?>"><i class="fa fa-plus"></i>载入/更新绩效明细表</a>
                    <a href="<?php echo e(url('excel/export_jixiao')); ?>"><i class="fa fa-plus"></i>导出EXCEL</a>
                </div>
            </div>
            <!--快捷导航 结束-->
        </div>

        <div class="result_wrap">
            <div class="result_content">
                <table class="list_tab">
                    <tr>
                        <th class="tc">序号</th>
                        <th>姓名</th>
                        <th>绩效工资基数</th>
                        <th>系数</th>
                        <th>上调20%</th>
                        <th>有限期奖惩</th>
                        <th>当月奖惩</th>
                        <th>未交月度考核表</th>
                        <th>本月实发数</th>
                    </tr>

                    <?php if(isset($data)): ?>
                        <?php foreach($data as $a =>$b): ?>
                    <tr>
                        <td class="tc"><?php echo e($b['jx2_id']); ?></td>
                        <td><?php echo e($b['jx2_name']); ?></td>
                        <td><?php echo e($b['jx2_base']); ?></td>
                        <td><?php echo e($b['jx2_xishu']); ?></td>
                        <?php /*<td><input type="checkbox" value="1" <?php if($b['jx2_if']==1): ?> checked <?php endif; ?>></td>*/ ?>
                        <td><div id="autoLogin"
                                 <?php if($b['jx2_if']==1): ?> class="mui-switch mui-active"
                                 <?php else: ?>  class="mui-switch"
                                <?php endif; ?> onclick="changeIf(this,jx2_id='<?php echo e($b['jx2_id']); ?>')">
                                <div class="mui-switch-handle"></div>
                            </div></td>
                        <td><?php echo e($b['jx2_float']); ?></td>
                        <td><input type="text" value="<?php echo e($b['jx2_random']); ?>" style="width: 50px;"></td>
                        <td><?php echo e($b['jx2_yue']); ?></td>
                        <td><?php echo e($b['jx2_shi']); ?></td>
                    </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </table>
                <?php if(isset($data)): ?>
                <div class="page_list">
                    <?php echo e($data->links()); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>
    <!--搜索结果页面 列表 结束-->

    <style>
        .result_content ul li span{
            padding:6px 12px;
        }
        .mui-switch:before {
            top: -4px;
        }
    </style>
    <script src="/resources/views/admin/style/js/login/js/mui.min.js"></script>
    <script src="/resources/views/admin/style/js/login/js/mui.enterfocus.js"></script>
    <script src="/resources/views/admin/style/js/login/js/app.js"></script>
    <script>
        $(function(){
            $('input[name=lin]').css('background-color','#C9C9C9');
        })
        function changeIf(obj,jx2_id){
            var index =$(obj).attr('class');
            if(index.indexOf('mui-active')>0){//此时按下
                $.post('<?php echo e(url('gongzi/changeif_jixiao')); ?>',{jx2_if:1,jx2_id:jx2_id,'_token':'<?php echo e(csrf_token()); ?>'},function(data){
                       if(data.status==0){
                            alert(data.msg);
                           setTimeout(function(){
                               location.href = location.href;
                           },500)
                       }
                       if(data.status==1){
                           alert(data.msg);
                           setTimeout(function(){
                               location.href = location.href;
                           },500)
                       }
                })
            }else{
                $.post('<?php echo e(url('gongzi/changeif_jixiao')); ?>',{jx2_if:0,jx2_id:jx2_id,'_token':'<?php echo e(csrf_token()); ?>'},function(data){
                        if(data.status==0){
                            alert('下调为0%');
                            setTimeout(function(){
                                location.href = location.href;
                            },500)
                        }
                        if(data.status==1){
                            alert(data.msg);
                            setTimeout(function(){
                                location.href = location.href;
                            },500)
                        }
                })
            }


        }
        //删除分类
        <?php /*function deleteObj(mx_id){*/ ?>
            <?php /*layer.confirm('确定删除这位仁兄？', {*/ ?>
                <?php /*btn: ['确定','取消'] //按钮*/ ?>
            <?php /*}, function(){*/ ?>
                <?php /*$.post("<?php echo e(url('admin/mx/')); ?>/"+mx_id,{'_method':'delete','_token':"<?php echo e(csrf_token()); ?>"},function(data){*/ ?>
                    <?php /*if(data.status=='0'){*/ ?>
                        <?php /*layer.msg(data.msg, {icon: 6});*/ ?>
                        <?php /*setTimeout(function(){*/ ?>
                            <?php /*location.href = location.href;*/ ?>
                        <?php /*},900)*/ ?>
                    <?php /*}else if(data.status=='1'){*/ ?>
                        <?php /*layer.msg(data.msg, {icon: 5});*/ ?>
                        <?php /*setTimeout(function(){*/ ?>
                            <?php /*location.href = location.href;*/ ?>
                        <?php /*},900)*/ ?>
                    <?php /*}else{*/ ?>
                        <?php /*layer.msg(data.msg, {icon: 5});*/ ?>
                        <?php /*setTimeout(function(){*/ ?>
                            <?php /*location.href = location.href;*/ ?>
                        <?php /*},900)*/ ?>
                    <?php /*}*/ ?>
                <?php /*});*/ ?>
            <?php /*});*/ ?>
        <?php /*}*/ ?>

        function searchName(){
            var val = $('#search').val();
            $.post("<?php echo e(url('admin/mx/search')); ?>",{name:val,'_token':'<?php echo e(csrf_token()); ?>'},function(data){
                $('tr:gt(0)').remove();
                    $(data).each(function(k,v){
                        var url1 ="jx/"+v.mx_id+"/edit";
                        var url2 = 'javascript:onclick=deleteObj('+v.mx_id+')';
                        $('tr:first').after("<tr><td class='tc'>"+v.mx_id+"</td>" +
                                "<td>"+v.mx_name+"</td>" +
                                "<td>"+v.mx_real+"</td>" +
                                "<td><a href='"+url1+"'>修改</a><a href="+url2+">删除</a></td></tr>");
                    })
            });
        }

        <?php /*function changeLin(obj,mx_id){*/ ?>
            <?php /*var $flag = $(obj).prop("readonly",false);*/ ?>
            <?php /*$(obj).attr({"readonly":false}).css('background-color','');*/ ?>
            <?php /*url = "<?php echo e(url('gongzi/lin_mingxi')); ?>";*/ ?>
            <?php /*obj.onkeydown = function(){*/ ?>
                <?php /*var e = event || window.event ||arguments.callee.caller.arguments[0];*/ ?>
                <?php /*var value = $(obj).val();*/ ?>
                <?php /*var value2 = mx_id;*/ ?>
                <?php /*if(e && e.keyCode ==13){*/ ?>
                    <?php /*$.post(url,{"mx_lin":value,"mx_id":value2,'_token':'<?php echo e(csrf_token()); ?>'},function(data){*/ ?>
                        <?php /*$(obj).prop('readonly','true').css('background-color','#C9C9C9');*/ ?>
                        <?php /*if(data.status=='0'){*/ ?>
                            <?php /*layer.msg(data.msg, {icon: 6});*/ ?>
                            <?php /*setTimeout(function(){*/ ?>
                                <?php /*location.href = location.href;*/ ?>
                            <?php /*},200)*/ ?>
                        <?php /*}else{*/ ?>
                            <?php /*layer.msg(data.msg, {icon: 5});*/ ?>
                            <?php /*setTimeout(function(){*/ ?>
                                <?php /*location.href = location.href;*/ ?>
                            <?php /*},200)*/ ?>
                        <?php /*}*/ ?>
                    <?php /*})*/ ?>
                <?php /*}*/ ?>
            <?php /*}*/ ?>

            <?php /*obj.onblur = function(){*/ ?>
                <?php /*var value = $(obj).val();*/ ?>
                <?php /*var value2 =mx_id;*/ ?>
                <?php /*var url = "<?php echo e(url('gongzi/lin_mingxi')); ?>";*/ ?>
                <?php /*$.post(url,{"mx_lin":value,"mx_id":value2,'_token':'<?php echo e(csrf_token()); ?>'},function(data){*/ ?>
                    <?php /*$(obj).prop('readonly','true').css('background-color','#C9C9C9');*/ ?>
                    <?php /*if(data.status=='0'){*/ ?>
                        <?php /*layer.msg(data.msg, {icon: 6});*/ ?>
                        <?php /*setTimeout(function(){*/ ?>
                            <?php /*location.href = location.href;*/ ?>
                        <?php /*},200)*/ ?>
                    <?php /*}else{*/ ?>
                        <?php /*layer.msg(data.msg, {icon: 5});*/ ?>
                        <?php /*setTimeout(function(){*/ ?>
                            <?php /*location.href = location.href;*/ ?>
                        <?php /*},200)*/ ?>
                    <?php /*}*/ ?>
                <?php /*})*/ ?>
            <?php /*}*/ ?>


        <?php /*}*/ ?>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>