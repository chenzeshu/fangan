<?php $__env->startSection('content'); ?>
    <!--面包屑导航 开始-->
    <div class="crumb_warp">
        <!--<i class="fa fa-bell"></i> 欢迎使用登陆网站后台，建站的首选工具。-->
        <i class="fa fa-home"></i> <a href="<?php echo e(url('gongzi/shui')); ?>">首页</a> &raquo; <a href="#">个人所得税表</a>
    </div>
    <!--面包屑导航 结束-->


    <!--搜索结果页面 列表 开始-->
        <div class="result_wrap">
            <div class="result_title">
                <h3>人员个税列表</h3>
            </div>
            <!--快捷导航 开始-->
            <div class="result_content">
                <div class="short_wrap">
                    <a href="<?php echo e(url('excel/export_gongzi')); ?>"><i class="fa fa-plus"></i>导出EXCEL表单</a>
                    <input type="text" name="name" class="xs" placeholder="填写查找姓名" id="search">
                    <input type="button" value="查找" onclick="searchName()">
                </div>
            </div>
            <!--快捷导航 结束-->
        </div>

        <div class="result_wrap">
            <div class="result_content">
                <table class="list_tab">
                    <tr>
                        <th class="tc">ID</th>
                        <th>纳税义务人姓名</th>
                        <th>招商银行账号</th>
                        <th>实发数</th>
                    </tr>
                    <?php foreach($mx as $k=>$v): ?>
                    <tr>
                        <td class="tc"><?php echo e($sum++); ?></td>
                        <td><?php echo e($v['mx_name']); ?></td>
                        <td><?php echo e($v['e_zhao']); ?></td>
                        <td><?php echo e($v['mx_shifa']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td class="tc"></td>
                        <td>合计</td>
                        <td></td>
                        <td><?php echo e($whole); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    <!--搜索结果页面 列表 结束-->

    <style>
        .result_content ul li span{
            padding:6px 12px;
        }
    </style>
    <script>
        //删除分类
        function deleteObj(id){
            layer.confirm('确定删除这位仁兄？', {
                btn: ['确定','取消'] //按钮
            }, function(){
                $.post("<?php echo e(url('gongzi/shui/')); ?>/"+id,{'_method':'delete','_token':"<?php echo e(csrf_token()); ?>"},function(data){
                    if(data.status=='0'){
                        layer.msg(data.msg, {icon: 6});
                        setTimeout(function(){
                            location.href = location.href;
                        },900)
                    }else if(data.status=='1'){
                        layer.msg(data.msg, {icon: 5});
                        setTimeout(function(){
                            location.href = location.href;
                        },900)
                    }else{
                        layer.msg(data.msg, {icon: 5});
                        setTimeout(function(){
                            location.href = location.href;
                        },900)
                    }
                });
            });
        }

        function searchName(){
            var val = $('#search').val();
            $.post("<?php echo e(url('gongzi/shui/search')); ?>",{name:val,'_token':'<?php echo e(csrf_token()); ?>'},function(data){
                $('tr:gt(0)').remove();
                    $(data).each(function(k,v){
                        var url1 ="base/"+v.id+"/edit";
                        var url2 = 'javascript:onclick=deleteObj('+v.id+')';
                        $('tr:first').after("<tr><td class='tc'>"+v.id+"</td>" +
                                "<td>"+v.name+"</td>" +
                                "<td>"+v.gong+"</td>" +
                                "<td>"+v.yang+"</td>" +
                                "<td><a href='"+url1+"'>修改</a><a href="+url2+">删除</a></td></tr>");
                    })
            });
        }
          <?php /*function changeOrder(obj,id){*/ ?>
              <?php /*var order = $(obj).val();*/ ?>
              <?php /*$.post('<?php echo e(url('gongzi/shui/changeorder')); ?>',{'_token':"<?php echo e(csrf_token()); ?>",'order':order,'id':id},function (data) {*/ ?>
                  <?php /*if(data.status=='0'){*/ ?>
                      <?php /*layer.alert(data.msg,{icon: 6});*/ ?>
                  <?php /*}else{*/ ?>
                      <?php /*layer.alert(data.msg,{icon: 5});*/ ?>
                  <?php /*}*/ ?>
              <?php /*})*/ ?>
          <?php /*}*/ ?>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>