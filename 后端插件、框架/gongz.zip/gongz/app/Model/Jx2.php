<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Jx2 extends Model
{
    protected $table = 'jx2';
    protected  $primaryKey = 'jx2_id';
    public $timestamps = false;
    protected $guarded =[];
}
