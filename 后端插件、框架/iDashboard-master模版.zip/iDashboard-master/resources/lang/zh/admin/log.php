<?php
return [
	'list' => '<i class="fa fa-list"></i> 系统日志列表',
];