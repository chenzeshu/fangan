<?php
return [
	'permissions' => '抱歉，你没有权限进行此操作',
];