<?php

namespace App\Repositories\Contracts;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface MenuRepository
 * @package namespace App\Repositories\Contracts;
 */
interface MenuRepository extends RepositoryInterface
{
    //
}
