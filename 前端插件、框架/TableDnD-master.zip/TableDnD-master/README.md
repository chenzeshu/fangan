# TableDnD

## Installation

The easiest way to install this is using:

`bower install https://github.com/isocra/TableDnD.git`

This will install the TableDnD plugin into your bower components as well as installing [jQuery](http://jquery.com) which it depends on.

Documentation will go here, for now, go to [Isocra's TableDnD Blog posting](http://www.isocra.com/2008/02/table-drag-and-drop-jquery-plugin/)

You can also play and experiment with TableDnD using this [jsFiddle](http://jsfiddle.net/DenisHo/dxpLrcd9/embedded/result/) (it's not complete yet, the ajax callbacks don't work--not surprisingly--but it's still useful for testing and exploring).
