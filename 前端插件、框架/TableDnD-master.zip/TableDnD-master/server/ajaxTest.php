The server says: your row order was<br/>
<?php
$result = $_REQUEST["table-3"];
foreach($result as $value) {
	echo "$value<br/>";
}
?>
See the <a href="server/ajaxTest_php.html" target="_BLANK">PHP Source</a><br/>